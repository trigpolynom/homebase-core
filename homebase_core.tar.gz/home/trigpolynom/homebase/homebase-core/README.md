# homebase
Multi-party workflow automation application built on top of RISC Zero


## Medical Billing example
